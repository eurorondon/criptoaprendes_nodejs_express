module.exports = {

    database: {
        connectionLimit: 10,
        host: '198.50.211.237',
        user: 'flashpoi_euro',
        password: 'Javieroca123-',
        database: 'flashpoi_remesafintech'
    }

};